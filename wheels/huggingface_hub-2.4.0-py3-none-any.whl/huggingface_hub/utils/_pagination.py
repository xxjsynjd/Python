# Copyright 2022-present, the HuggingFace Inc. team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Contains utilities to handle pagination on Huggingface Hub."""

from collections.abc import Iterable
from typing import Any

import httpx2

from . import hf_raise_for_status, http_backoff, logging


logger = logging.get_logger(__name__)


def _paginate_pages(
    path: str, params: dict | list[tuple[str, Any]], headers: dict, timeout: float | None = None
) -> Iterable[tuple[list, bool]]:
    """Fetch a list of models/datasets/spaces and paginate through results, page by page.

    Same as [`paginate`] but results are yielded one page at a time as a tuple (page, finished).
    It allows a caller to stop early (the remaining pages are then never requested) or to make
    a decision in between two pages based on what has been fetched so far.

    This is using the same "Link" header format as GitHub.
    See:
    - https://requests.readthedocs.io/en/latest/api/#requests.Response.links
    - https://docs.github.com/en/rest/guides/traversing-with-pagination#link-header
    """
    r = http_backoff("GET", path, params=params, headers=headers, timeout=timeout)
    hf_raise_for_status(r)
    # Follow pages
    # Next link already contains query params
    next_page = _get_next_page(r)
    yield r.json(), next_page is None

    while next_page is not None:
        logger.debug(f"Pagination detected. Requesting next page: {next_page}")
        r = http_backoff("GET", next_page, headers=headers, timeout=timeout)
        hf_raise_for_status(r)
        next_page = _get_next_page(r)
        yield r.json(), next_page is None


def paginate(path: str, params: dict | list[tuple[str, Any]], headers: dict, timeout: float | None = None) -> Iterable:
    """Fetch a list of models/datasets/spaces and paginate through results.

    This is using the same "Link" header format as GitHub.
    See:
    - https://requests.readthedocs.io/en/latest/api/#requests.Response.links
    - https://docs.github.com/en/rest/guides/traversing-with-pagination#link-header
    """
    for page, _ in _paginate_pages(path, params, headers, timeout=timeout):
        yield from page


def _get_next_page(response: httpx2.Response) -> str | None:
    return response.links.get("next", {}).get("url")
