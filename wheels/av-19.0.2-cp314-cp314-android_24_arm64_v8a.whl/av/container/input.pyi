from collections.abc import Iterator
from typing import Any, overload

from av.audio.frame import AudioFrame
from av.audio.stream import AudioStream
from av.packet import Packet
from av.stream import AttachmentStream, DataStream, Stream
from av.subtitles.stream import SubtitleStream
from av.subtitles.subtitle import SubtitleSet
from av.video.frame import VideoFrame
from av.video.stream import VideoStream

from .core import Container

class InputContainer(Container):
    start_time: int
    start_time_realtime: int | None
    duration: int | None
    bit_rate: int
    size: int | None

    @overload
    def demux(self, video_stream: VideoStream) -> Iterator[Packet[VideoStream]]: ...
    @overload
    def demux(
        self, video_streams: tuple[VideoStream, ...]
    ) -> Iterator[Packet[VideoStream]]: ...
    @overload
    def demux(self, *, video: Any) -> Iterator[Packet[VideoStream]]: ...
    @overload
    def demux(self, audio_stream: AudioStream) -> Iterator[Packet[AudioStream]]: ...
    @overload
    def demux(
        self, audio_streams: tuple[AudioStream, ...]
    ) -> Iterator[Packet[AudioStream]]: ...
    @overload
    def demux(self, *, audio: Any) -> Iterator[Packet[AudioStream]]: ...
    @overload
    def demux(
        self, subtitle_stream: SubtitleStream
    ) -> Iterator[Packet[SubtitleStream]]: ...
    @overload
    def demux(
        self, subtitle_streams: tuple[SubtitleStream, ...]
    ) -> Iterator[Packet[SubtitleStream]]: ...
    @overload
    def demux(self, data_stream: DataStream) -> Iterator[Packet[DataStream]]: ...
    @overload
    def demux(
        self, data_streams: tuple[DataStream, ...]
    ) -> Iterator[Packet[DataStream]]: ...
    @overload
    def demux(self, *, data: Any) -> Iterator[Packet[DataStream]]: ...
    @overload
    def demux(
        self, attachment_stream: AttachmentStream
    ) -> Iterator[Packet[AttachmentStream]]: ...
    @overload
    def demux(
        self, attachment_streams: tuple[AttachmentStream, ...]
    ) -> Iterator[Packet[AttachmentStream]]: ...
    @overload
    def demux(self, *args: Any, **kwargs: Any) -> Iterator[Packet[Stream]]: ...
    @overload
    def decode(self, video: int) -> Iterator[VideoFrame]: ...
    @overload
    def decode(self, audio: int) -> Iterator[AudioFrame]: ...
    @overload
    def decode(self, subtitles: int) -> Iterator[SubtitleSet]: ...
    @overload
    def decode(self, *args: VideoStream) -> Iterator[VideoFrame]: ...
    @overload
    def decode(self, *args: AudioStream) -> Iterator[AudioFrame]: ...
    @overload
    def decode(self, *args: SubtitleStream) -> Iterator[SubtitleSet]: ...
    @overload
    def decode(
        self, *args: Any, **kwargs: Any
    ) -> Iterator[VideoFrame | AudioFrame | SubtitleSet]: ...
    def seek(
        self,
        offset: int,
        *,
        backward: bool = True,
        any_frame: bool = False,
        stream: Stream | VideoStream | AudioStream | None = None,
        unsupported_frame_offset: bool = False,
        unsupported_byte_offset: bool = False,
    ) -> None: ...
